<?php 
session_start();

if(!isset($_SESSION['username'])){
  header("Location: login.php");
}

?><!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Contact-Lenses</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="js/custom.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Bilbo+Swash+Caps" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Kalam" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <div id="wrapper">
      <?php include("includes/header.php"); ?>
        <!-- <?php include('includes/nav.php'); ?> -->
      <main>               
        <section class="w50">        
          <form name="shopForm" method="Post" action="">
         
            <div class="products-grid">
              <div class="row">
                <div class="acuve-product1">
                  <img src="Images/acuve.jpeg" alt="acuve" >
                  <h3>Acuvue Oasys 2-Week 24pk</h3>
                  <div class="price-qty">
                    <div class="quantity">
                      <label for="lens">Quantity:</label>
                        <select name="lens" id="lens">
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                        </select>
                    </div>
                    <div class="price">Price: <span>$7.99 PER BOX</span></div>
                  </div>
                </div>
                <div class="acuve-product1">
                  <img src="Images/biotrue.jpeg" alt="Biotrue" >
                  <h3>Biotrue Oneday 30pk - Clear</h3>
                  <div class="price-qty">
                    <div class="quantity">
                      <label for="lens1">Quantity:</label>
                        <select name="lens1" id="lens1">
                          <option value="0">0</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                        </select>
                    </div>
                    <div class="price">Price: <span>$6.99 PER BOX</span></div>
                  </div>      
                </div>
              </div>
            </div>
            <div id="printablediv" style="display:none;" >
                <table border="1" cellpadding="3" id="printTable">
                  <tbody><tr>
                      <th>Item</th>
                      <th>Quantity</th>      
                      <th>Unit Price</th>
                      <th>Total</th>
                  </tr>
                  <tr>
                      <td id="Acuve">Acuvue Oasys 2-Week 24pk</td>
                      <td id="AcuveQuantity"></td>      
                      <td id="AcuvePrice">7.99</td>  
                      <td id="Total"></td>
                  </tr>
                  <tr>
                    <td id="Biotrue">Biotrue Oneday 30pk - Clear</td>
                    <td id="BiotrueQuantity"></td>      
                    <td id="BiotruePrice">6.99</td>  
                    <td id="BiotrueTotal"></td>
                  </tr>  
                  <tr>
                    <td>SubTotal</td>
                    <td></td>      
                    <td></td>  
                    <td id="totalCost"></td>
                  </tr> 
                  <tr>
                    <td>Tax</td>
                    <td></td>      
                    <td></td>  
                    <td id="provinceTax"></td>
                  </tr>  
                  <tr>
                    <td>Total</td>
                    <td></td>      
                    <td></td>  
                    <td id="totalPrice"></td>
                  </tr>            
                 
              </tbody></table>
             <!-- // <div id="name" ></div>
              <div id="email" ></div>
              <div id="addressDet" ></div> -->
              </div>
            <div class="basic-details">
                <h3>Basic Details</h3>
                <div class="form-row">
                  <div class="form-width">
                      <label for="fname">First Name <span class="asterik">*</span></label>
                      <div>
                      <input type="text" id="fname" name="firstname" placeholder="Your name.." >
                      </div>
                      <span id="input-FirstName" class="text-danger"></span>
                  </div>
                    <div class="form-width">
                        <label for="lname">Last Name <span class="asterik">*</span></label>
                        <div>
                        <input type="text" id="lname" name="lastname" placeholder="Your last name..">
                        </div>
                        <span id="input-LastName" class="text-danger"></span>
                    </div>
                </div>
                <div class="form-row">
                  <div class="form-width">
                      <label for="femail">Email <span class="asterik">*</span></label>
                      <div>
                      <input type="text" id="femail" name="email" placeholder="Your email..">
                      </div>
                      <span id="input-Email" class="text-danger"></span>
                  </div>
                    <div class="form-width">
                      <label for="lphone">Phone <span class="asterik">*</span></label>
                      <div>
                      <input type="text" id="lphone" name="phone" placeholder="Your phone..">
                      </div>
                      <span id="input-phone" class="text-danger"></span>
                    </div>
                </div>                                 
              <div class="address-details">
                <h3>Address Details</h3>
                <div class="form-row">
                  <div class="form-width">
                      <label for="faddress">Address <span class="asterik">*</span></label>
                      <div>
                      <input type="text" id="faddress" name="address" placeholder="Your address..">
                      </div>
                      <span id="input-faddress" class="text-danger"></span>
                  </div>
                    <div class="form-width">
                      <label for="lname">City <span class="asterik">*</span></label>
                      <div>
                      <input type="text" id="lcity" name="city" placeholder="Your city..">
                      </div>
                      <span id="input-lcity" class="text-danger"></span>
                    </div>
                </div>
                <div class="form-row">
                  <div class="form-width">
                      <label for="fstate">State <span class="asterik">*</span></label>
                      <div>       
                          <select name="state" id="fstate">
                            <option value="ON">ON</option>
                            <option value="BC">BC</option>
                            <option value="QC">QC</option>
                            <option value="NS">NS</option>
                            <option value="AB">AB</option>
                            <option value="AB">MB</option>
                          </select>
                      </div>
                      <span id="input-fstate" class="text-danger"></span>
                  </div>
                    <div class="form-width">
                      <label for="lzip">Zip Code <span class="asterik">*</span> </label>
                      <div>
                      <input type="text" id="lzip" name="zip" placeholder="Your zip..">
                      </div>
                      <span id="input-lzip" class="text-danger"></span>
                    </div>
                </div>
              </div>            
              <div class="buynow-button">       
              <input type="submit" value="Register" class="btn btn-secondary" name="submit">
                </div>
             </div>

          </form>
        </section>
          <section class="w50">
            <div class="formData">
              <p id="formResult">
                <?php
                  // server-side output in PHP
                    if(isset($_POST["submit"])){
                    $firstname = $_POST['firstname'];
                    $lastname = $_POST['lastname'];
                    $email = $_POST['email'];
                    $phone = $_POST['phone'];
                    $address = $_POST['address'];
                    $city = $_POST['city'];
                    $state = $_POST['state'];
                    $zip = $_POST['zip'];
                    $lens = $_POST['lens'];
                    $productName;
                    if($lens > 0){
                      $productName = "Acuvue Oasys 2-Week 24pk";
                    }
                    $acuTotal = $lens * 7.99;
                    $lens1 = $_POST['lens1'];
                    if($lens1 > 0){
                      $productName = "Biotrue Oneday 30pk - Clear";
                    }
                    $bioTotal = $lens1 * 6.99;
                    $quantity= $lens + $lens1;
                    $totalWithouttax = $acuTotal + $bioTotal;
                      $tax;
                      if($state == "ON"){
                        $tax = $totalWithouttax * 0.13;
                      }
                      else if($state == "BC"){
                        $tax = $totalWithouttax * 0.12;
                      }
                      else if($state == "QC"){
                        $tax = $totalWithouttax * 0.1497;
                      }
                      else if($state == "NS"){
                        $tax = $totalWithouttax * 0.15;
                      }
                      else if($state == "MB"){
                        $tax = $totalWithouttax * 0.12;
                      }
                      else {
                        $tax = $totalWithouttax * 0.15;
                      }
                      $cost = $totalWithouttax + $tax;

                      include "includes/db_connection.php";

                      if(isset($_POST["submit"])){
                      
                          if($query = mysqli_query($db,"INSERT INTO lensorders (`id`, `firstname`,`lastname`,`email`,`phone`, `address`,`city`,`state`,`zip`,`productname`,`quantity`,`price`,`tax`,`totalCost`) VALUES ('', '".$firstname."', '".$lastname."','".$email."','".$phone."','".$address."','".$city."','".$state."','".$zip."','".$productName."','".$quantity."','".$totalWithouttax."','".$tax."','".$cost."')")){
                              echo "Success";
                          }else{
                              echo "Failure" . mysqli_error($connect);
                          }
                      }

                    // echo "Name: $firstname $lastname <br>";
                    // echo "Email: $email <br>";
                    // echo "Phone: $phone <br>";
                    // echo "Address: $address <br>";
                    // echo "City: $city <br>";
                    // echo "State: $state <br>";
                    // echo "Lens: $lens <br>";
                    // echo "Lens1: $lens1 <br>";
                    // echo "totalWithouttax : $totalWithouttax <br>";
                    // echo "tax : $tax <br>";
                    // echo "cost : $cost <br>";
                    // echo "productName : $productName <br>";
                    echo '<script type="text/javascript">',
     'checkForm();',
     '</script>'
;
                  }
                  // isset POST if statement ends here
                 
                ?>
              </p>
            </div>
          </section>
          <div class="clear"></div>
      </main>
  </div>
</body>

</html>