<header>
          <div class="header-banner">
            <div>
            <img src="Images/svs-cle-logo.png" alt="svs-logo" >
            </div>
            <nav class="top_menu">
              <ul>              
                <?php 
                if(isset($_SESSION['username']) && ($_SESSION['username'] == "admin" || $_SESSION['username'] == "shopmanager" )) {

                ?> 
                <li>
                  <a href="orders.php">All Orders</a>
                </li>

                 <?php } ?> 

                 <?php 
                if(isset($_SESSION['username']) && $_SESSION['username'] == "admin") {

                ?> 
                <li>
                  <a href="shopmanagers.php">Shop Manager page</a>
                </li>
                <?php } ?> 
                <?php 
                if(!isset($_SESSION['username'])){ ?>
                    <li>
                      <a href="login.php">Login</a>
                    </li>
                    <?php } ?>
                 <?php 
                if(isset($_SESSION['username'])) { ?> 
                <li>
                  <a href="logout.php">Logout</a>
                </li>
                 <?php } ?> 
              </ul>
            </nav>
            <div>
              <img src="Images/svs1.png" alt="svs-logo" >
              </div>
          </div>       
  </header>