  <nav class="top_menu">
    <ul>
      <li>
        <a href="index.php">Order Form</a>
      </li>

      <?php 
      if(isset($_SESSION['username']) && $_SESSION['username'] == "admin") {

      ?>
      <li>
        <a href="orders.php">All Orders</a>
      </li>

      <?php } ?>

      <?php 
      if(!isset($_SESSION['username'])){ ?>
      <li>
        <a href="login.php">Login</a>
      </li>
      <?php } ?>
      <?php 
      if(isset($_SESSION['username'])) { ?>
      <li>
        <a href="logout.php">Logout</a>
      </li>
      <?php } ?>
    </ul>
  </nav>