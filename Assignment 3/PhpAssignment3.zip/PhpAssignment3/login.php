<?php
session_start();
if(isset($_SESSION['username'])){
  echo "You are already logged in";
}
else {


  include "includes/db_connection.php";
  if(isset($_POST['username'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM user_login WHERE username = '$username' AND password='$password'";
    $result = $db->query($sql);
    $row = $result->fetch_assoc();
    if($row){
      $_SESSION['username'] = $row['username'];
      $_SESSION['userid'] = $row['id'];
      header("Location: index.php");
    }
    else echo "The user/pass is invalid";
  }
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Contact-Lenses</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="js/custom.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Bilbo+Swash+Caps" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Kalam" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
 
<body>
  <?php include('includes/header.php'); ?>
  <main>
    <form name="loginForm" method="Post" action="">
    <h1 style="font-weight:bold">User Login</h1>
    <p class="success" style="font-size:20px" id="login-unsuccess">Welcome back to the SVS Vision Contact Lens Store. Returning users, please enter your username and password below to sign into your account to view current prescriptions, place new orders, and more.</p>
      <label>Username</label>
      <input id="username" type="text" name="username"><br />

      <label>Password</label>
      <input id="password" type="password" name="password"><br />


      <br /><br />

      <input type="submit" value="Log In" class="btn btn-secondary">
      <p id="errors"></p>
    </form>
  </main>
  
  <div class="clear"></div>
</body>

</html>
<?php
}
?>