<?php
session_start();
if(!isset($_SESSION['username'])){
  header("Location: login.php");
}
else{
  if ($_SESSION['username'] != "admin" && $_SESSION['username'] != "shopmanager" ){
   // echo "unauthorized to view this page";
   header("Location: login.php");
  }
  else {


?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Contact-Lenses</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="js/custom.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Bilbo+Swash+Caps" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Kalam" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
  <?php include("includes/header.php"); ?>
  <h3>All Orders</h3>
<?php
   include "includes/db_connection.php";
   $sql = "SELECT * FROM lensorders";
   $result = $db->query($sql);
   
   if ($result->num_rows > 0) {
       echo "<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>City</th><th>ProductName</th><th>Cost</th></tr>";
       // output data of each row
       while($row = $result->fetch_assoc()) {
           echo "<tr>
           <td>" . $row["id"]. "</td>
           <td>" . $row["firstname"]. " " . $row["lastname"]. "</td>
           <td>" . $row["email"]. "</td>
           <td>" . $row["phone"]. "</td>
           <td>" . $row["address"]. "</td>
           <td>" . $row["city"]. "</td>
           <td>" . $row["productname"]. "</td>
           <td>" . $row["totalCost"]. "</td>
           </tr>";
       }
       echo "</table>";
   } else {
       echo "0 results";
   }
   
   $db->close();
 ?>
 </body>
</html>

<?php
  }
}

?>