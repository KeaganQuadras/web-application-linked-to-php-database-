function checkForm(){
var fname = document.getElementById("fname").value;
    var e = document.getElementById("lens");
  var selectedValue = e.options[e.selectedIndex].value;
  var ef = document.getElementById("lens1");
  var selectedValue1 = ef.options[ef.selectedIndex].value;
  var stateVal = document.getElementById("fstate");
  var selectedstateVal = stateVal.options[stateVal.selectedIndex].value;
  document.getElementById("AcuveQuantity").textContent = parseInt(selectedValue);
  var acuTotal = document.getElementById("Total").textContent =(parseInt(selectedValue) * 7.99);
   document.getElementById("BiotrueQuantity").textContent = parseInt(selectedValue1);
  var bioTotal =  document.getElementById("BiotrueTotal").textContent = parseInt(selectedValue1) * 6.99;
  console.log(selectedstateVal);
  var totalWithouttax = acuTotal + bioTotal;
        console.log(totalWithouttax);
        var tax ;
        if(selectedstateVal == "ON"){
          tax =  totalWithouttax * 0.13;
        }
        else if(selectedstateVal == "BC"){
          tax =  totalWithouttax * 0.12;
        }
        else if(selectedstateVal == "QC"){
          tax =  totalWithouttax * 0.1497;
        }
        else if(selectedstateVal == "NS"){
          tax =  totalWithouttax * 0.15;
        }
        else if(selectedstateVal == "MB"){
          tax =  totalWithouttax * 0.12;
        }
        else{
          tax =  totalWithouttax * 0.15;
        }
        console.log("tax is " +tax);
        document.getElementById("provinceTax").textContent = tax;
        var cost = totalWithouttax + tax ; 
                 
         document.getElementById("totalPrice").textContent = cost;
        document.getElementById("totalCost").textContent = (parseFloat(selectedValue) * 7.99) + ( parseFloat(selectedValue1) * 6.99);
        //document.getElementById("name").textContent = "Name : " + fname + " " + document.getElementById("lname").value;
       // document.getElementById("email").textContent = "Email : " + document.getElementById("femail").value ;
       // document.getElementById("addressDet").textContent = "Address : " + document.getElementById("faddress").value + "," + document.getElementById("lcity").value  + "," + document.getElementById("fstate").value  ;
  
        var divElements = document.getElementById("printablediv").innerHTML;
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //Reset the page's HTML with div's HTML only
        document.body.innerHTML = 
          "<html><head><title></title></head><body>" + 
          divElements + "</body>";
        //Print Page
        window.print();       
      }
    