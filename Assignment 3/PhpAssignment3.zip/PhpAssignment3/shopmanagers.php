<?php
session_start();
if(!isset($_SESSION['username'])){
  header("Location: login.php");
}
else{
  if ($_SESSION['username'] != "admin"  ){
   // echo "unauthorized to view this page";
   header("Location: login.php");
  }
  else {


?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Contact-Lenses</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="js/custom.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Bilbo+Swash+Caps" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Kalam" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
 
<body>
  <?php include('includes/header.php'); ?>
  <main>
    <form name="shopManagersForm" method="Post" action="">
    <h1 style="font-weight:bold">Shop Manager User</h1>
    <p class="success" style="font-size:20px" id="login-unsuccess">Welcome back to the SVS Vision Contact Lens Store. Here Admin can create a user.</p>
      <label>Username</label>
      <input id="username" type="text" name="firstName"><br />

      <label>Password</label>
      <input id="password" type="password" name="pwd"><br />


      <br /><br />

      <input type="submit" value="Register" class="btn btn-secondary" name="submit">
      <p id="errors"></p>
    </form>
  </main>
  
  <div class="clear"></div>
</body>

</html>
<?php
   include "includes/db_connection.php";

    if(isset($_POST["submit"])){
      $username = $_POST['firstName'];
      $password = $_POST['pwd'];
        if($query = mysqli_query($db,"INSERT INTO user_login (`id`, `username`, `password`) VALUES ('', '".$username."', '".$password."')")){
            echo "Success";
        }else{
            echo "Failure" . mysqli_error($connect);
        }
    }  

   
?>
<?php
  }
}

?>
